#include "linkedlist.h"

//time: O(1)
node* createNode(void* data,int size){
	node* n = malloc(sizeof *n);
	n->data = malloc(size);
	strcpy((char*)n->data, (char*)data);
	n->prev = NULL;
	n->next = NULL;
	return n;
}

//time: O(1)
list* createList(int maxSize){
	list* l = malloc(sizeof *l);
	l->head = NULL;
	l->tail = NULL;
	l->curr = NULL;
	l->pos = -1;
	l->size = 0;
	l->maxSize = maxSize;
	return l;
}

//time: O(1)
void delNode(node* n){
	free(n->data);
	n->data = NULL;
	n->prev = NULL;
	n->next = NULL;
	free(n);
	n = NULL;
}

//time: O(n)
void delList(list* l){
	node* curr = l->tail;
	while(curr != NULL){
		curr = curr->prev;
		if(curr != NULL){
			delNode(curr->next);
			curr->next = NULL;
			
		} 
	}
	delNode(l->head);
	l->head = NULL;
	l->tail = NULL;
	l->curr = NULL;
	l->pos = -1;
	l->size=0;
	free(l);
	l = NULL;	
}

void append(void* data, int size, list* l){
	node* n = createNode(data, size);
	if(l->tail == NULL && l->head == NULL){
		l->head = n;		
	}
	node* tail = l->tail;
	n->prev = tail;
	if(tail != NULL){
		tail->next = n;
	}
	l->tail = n;
	l->curr = l->tail;
	l->pos += 1;
	l->size+=1;
}


//removes node at the head of the list
void removeNode(list* l){
	//change where head is pointing
	node* oldHead = l->head;
	l->head = oldHead->next;
	//new head needs to set prev to null
	l->head->prev = NULL;
	//old head node needs to be freed
	delNode(oldHead);
	l->size -= 1;
	//reduces position index of current by one unless already 0(head)
	if(l->pos != 0){
		l->pos -= 1;
	}	
}

//Current moves back one towards the head of the list
void back(list* l){
	if(l->curr != NULL){
		l->pos-=1;
		l->curr = l->curr->prev;
	}	
}

//Current moves forward one towards the tail of the list
void forward(list* l){
	if(l->curr != NULL){
		l->pos+=1;
		l->curr = l->curr->next;
	}	
}

//forgets subsequent URLs after current
void forget(list* l){
	node* it = l->tail;
	while(it!=l->curr){
		it = it->prev;
		l->tail = it;
		delNode(it->next);
		it->next=NULL;
		l->size-=1;
	}
}

//prints their history from current in reverse order to start(head)
void printCurrReverse(list* l){
	node* it = l->curr;
	while(it!=NULL){
		printf("%s ", (char*)it->data);
		it = it->prev;
	}
	printf("\n\n");		
}

//prints their history from current in order to end(tail)
void printCurrForward(list* l){
	
	node* it = l->curr;
	while(it!=NULL){
		printf("%s ", (char*)it->data);
		it = it->next;
	}
	printf("\n\n");	
}

//prints entire list labeling the current URL with an *
void printEntireList(list* l){
	node* it = l->head;
	while(it!=NULL){
		if(it==l->curr){
			printf("*https://www.%s.com -- ", (char*)l->curr->data);
		}
		else{
			printf("https://www.%s.com -- ", (char*)it->data);
		}
		it = it->next;
	}
	
	printf("\n\n");
}


