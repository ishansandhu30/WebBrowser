#include "test.h"

void createNodeTest(){
	char* url = "https://www.google.com";
	printf("createNodeTest\n");
	printf("--------------\n");
	node* n = createNode(url,strlen(url)*sizeof *url+1);
	int same = (strcmp(url,n->data)==0);
	if(same){
		printf("PASS\n\n");
	}
	else{
		printf("FAIL\n\n");
	}
	delNode(n);
}

void appendTest(){	
	printf("Append Test\n");
	printf("-----------\n");
	int maxSize = 10;	
	list* l = createList(maxSize);
	char* url = "https://www.google.com";
	append(url, strlen(url)*sizeof *url+1, l);
	node* tail = l->tail;
	printf("l->tail->data: %s\n",(char*)tail->data);
	printf("l->size: %d\n", l->size);	
	node* head = l->head;
	printf("l->head->data: %s\n",(char*)head->data);
	node* curr = l->curr;
	if(curr != NULL){
		 printf("l->curr->data: %s\n",(char*)curr->data);
	}
	if(strcmp(head->data,tail->data)==0 && strcmp(curr->data, tail->data)==0 && l->size==1){
		printf("PASS\n\n");
	}
	else{
		printf("FAIL\n\n");
		
	assert(strcmp(head->data,tail->data)==0);
	assert(strcmp(curr->data, tail->data)==0);
	assert(l->size==1);
	}
	
	url = "https://www.youtube.com";
	append(url, strlen(url)*sizeof *url+1, l);
	tail = l->tail;
	printf("l->tail->data: %s\n",(char*)tail->data);
	printf("l->size: %d\n", l->size);	
	head = l->head;
	printf("l->head->data: %s\n",(char*)head->data);
	curr = l->curr;
	if(curr != NULL){
		 printf("l->curr->data: %s\n",(char*)curr->data);
	}
	if(strcmp(head->data,tail->data)!=0 && strcmp(curr->data, tail->data)==0 && l->size==2){
		printf("PASS\n\n");
	}
	else{
		printf("FAIL\n\n");
		assert(strcmp(head->data,tail->data) != 0);
		assert(strcmp(curr->data,tail->data)==0);
		assert(l->size == 2);
	}
	
	url = "https://www.tiktok.com";
	append(url, strlen(url)*sizeof *url+1, l);
	tail = l->tail;
	printf("l->tail->data: %s\n",(char*)tail->data);
	printf("l->size: %d\n", l->size);	
	head = l->head;
	printf("l->head->data: %s\n",(char*)head->data);
	curr = l->curr;
	if(curr != NULL){
		 printf("l->curr->data: %s\n",(char*)curr->data);
	}
	if(strcmp(head->data,tail->data)!=0 && strcmp(curr->data, tail->data)==0 && l->size==3){
		printf("PASS\n\n");
	}
	else{
		printf("FAIL\n\n");
		assert(strcmp(head->data,tail->data) != 0);
		assert(strcmp(curr->data,tail->data)==0);
		assert(l->size == 3);
	}
	
	url = "https://www.instagram.com";
	append(url, strlen(url)*sizeof *url+1, l);
	tail = l->tail;
	printf("l->tail->data: %s\n",(char*)tail->data);
	printf("l->size: %d\n", l->size);	
	head = l->head;
	printf("l->head->data: %s\n",(char*)head->data);
	curr = l->curr;
	if(curr != NULL){
		 printf("l->curr->data: %s\n",(char*)curr->data);
	}
	if(strcmp(head->data,tail->data)!=0 && strcmp(curr->data, tail->data)==0 && l->size==4){
		printf("PASS\n\n");
	}
	else{
		printf("FAIL\n\n");
		assert(strcmp(head->data,tail->data) != 0);
		assert(strcmp(curr->data,tail->data)==0);
		assert(l->size == 4);
	}
	delList(l);
}
list* appendNodes(){
	int maxSize = 10;
	list* l = createList(maxSize);
	char* url = "https://www.google.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.apple.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.bing.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.microsoft.com";
	append(url, strlen(url)*sizeof *url+1, l);
	return l;
}

int removeNodeTest(){
	printf("---------------\n");
	list* l = createList(10);
	char* url = "https://www.google.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.apple.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.bing.com";
	append(url, strlen(url)*sizeof *url+1, l);
	removeNode(l);
	printf("Data in head of list: %s\n", (char*)l->head->data);
	printf("Data in tail of list: %s\n", (char*)l->tail->data);
	printf("size of list: %d\n", l->size);
	printf("position of list: %d\n", l->pos);
	delList(l);
	return 0;
}

int backForwardTest(){	
	printf("-------------------\n");
	list* l = createList(10);
	char* url = "https://www.google.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.apple.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.bing.com";
	append(url, strlen(url)*sizeof *url+1, l);
	back(l);
	printf("current URL: %s\n", (char*)l->curr->data);
	forward(l);
	printf("current URL: %s\n", (char*)l->curr->data);
	delList(l);
	return 0;
}

int forgetNodeTest(){
	printf("----------------------\n");
	list* l = createList(10);
	char* url = "https://www.google.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.apple.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.bing.com";	
	append(url, strlen(url)*sizeof *url+1, l);

	url = "https://www.samsung.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.canvas.com";
	append(url, strlen(url)*sizeof *url+1, l);
	back(l);
	back(l);
	forget(l);	
	printf("Data in head of list: %s\n", (char*)l->head->data);
	printf("Data in tail of list: %s\n", (char*)l->tail->data);
	printf("size of list: %d\n", l->size);
	printf("position of list: %d\n", l->pos);
	delList(l);
	return 0;
	
}
	
int printTest(){	
	printf("----------------------\n");
	list* l = createList(10);
	char* url = "https://www.google.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.apple.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.bing.com";	
	append(url, strlen(url)*sizeof *url+1, l);

	url = "https://www.samsung.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.canvas.com";
	append(url, strlen(url)*sizeof *url+1, l);
	back(l);
	back(l);
	printf("Entire List: ");
	printEntireList(l);
	printf("List after curr: ");
	printCurrForward(l);
	printf("List before curr: ");
	printCurrReverse(l);
	delList(l);
	return 0;
}
int addAfterCurrTest(){

	printf("----------------------\n");
	list* l = createList(10);
	char* url = "https://www.google.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.apple.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.bing.com";	
	append(url, strlen(url)*sizeof *url+1, l);

	url = "https://www.samsung.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.canvas.com";
	append(url, strlen(url)*sizeof *url+1, l);
	back(l);
	back(l);
	url = "https://www.nba.com";
		
	printf("Entire List before addAfterCurr: ");
	printEntireList(l);
	addAfterCurr(l,url);
	printf("Entire List after addAfterCurr: ");
	printEntireList(l);
	delList(l);
	return 0;
}

int readWriteTest(){
	printf("----------------------\n");
	int mSize = 10;
	list* l = createList(mSize);
	char* url = "https://www.google.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.apple.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.bing.com";	
	append(url, strlen(url)*sizeof *url+1, l);

	url = "https://www.samsung.com";
	append(url, strlen(url)*sizeof *url+1, l);
	
	url = "https://www.canvas.com";
	append(url, strlen(url)*sizeof *url+1, l);
	back(l);
	back(l);
	printf("printing l \n");
	printEntireList(l);
	char* h = "history.bin";
	char* pad = "pad.bin";
        writeFile(h,pad,l);
	list* newL = createList(mSize);
	readFile(h,pad,newL);	
//	printf("h: %s \n", h);
//	printf("pad: %s \n", pad);
//	printf("newl: %d \n", newL->size);	
	printf("printing newL \n");
	printEntireList(newL);
	delList(l);	
	delList(newL);
	return 0;
}
