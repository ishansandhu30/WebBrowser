#ifndef TEST_H
#define TEST_H
#include "linkedlist.h"
#include "history.h"

void createNodeTest();
void appendTest();
list* appendNodes();
int removeNodeTest();
int backForwardTest();
int forgetNodeTest();
int printTest();
int addAfterCurrTest();
int readWriteTest();
#endif //TEST_H
