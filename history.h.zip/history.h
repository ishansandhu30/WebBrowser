#include <stdio.h>
#include "linkedlist.h"

//checks curr to see if last in list
//if last in list forget anything after curr and add  new URL after curr
void addAfterCurr(list* l, char* url);
char* readUrl(FILE* f, FILE* pad);
// pad is the pad file name not actual pad
int readFile(char* f, char* padFile, list* l);
//decrypting position of current pointer
int decryptNum(FILE* pad, int num);
//decrypting character in a URL
char decryptChar(FILE* pad, char c);
// pad is the pad file name not actual pad
int writeFile(char* f, char* padFile, list* l);
char* createPad(int size);
void writePad(FILE* padFile, char* pad);
int countUrlChar(list* l);
char* encryptURL(FILE* pad, char* url);
// encrypts position or curr
int encryptNum(FILE* pad, int num);

