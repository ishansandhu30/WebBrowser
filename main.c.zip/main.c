#include "linkedlist.h"
#include "test.h"
#include "history.h"
#include "driver.h"

int main(int argc, char* argv[]){
	printf("Web Browser History \n");
	printf("--------------------\n");
	printf("argc: %d\n",argc);
	printf("argv[0]: %s\n",argv[0]);
	if(argc==3 && strcmp(argv[1],"i")==0){
		printf("argv[1]: %s\n",argv[1]);
	//	printf("Call driver function runDriver()\n");
		interact(10, "pad.bin", argv[2]);
	}
	else if(argc==3 && strcmp(argv[1],"p")==0){
		printf("Printing: %s\n", argv[2]);
		printHistory(10, "pad.bin", argv[2]);
	}
	//run tests
	else if(argc==1){
		createNodeTest();
		appendTest();
		removeNodeTest();
		backForwardTest();
		forgetNodeTest();
		printTest();
		addAfterCurrTest();
		readWriteTest();
	}
	return 0;
}
