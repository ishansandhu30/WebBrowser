#ifndef DRIVER_H 
#define DRIVER_H 
#include "history.h" 

void printHistory(int maxSize, char* padFile, char* hFile);

void interact(int maxSize, char* padFile, char* hFile);

char menu();

void switchAct(char* c, char* padFile, char* hFile, list* l);
#endif //DRIVER_H
