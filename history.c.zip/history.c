#include "history.h"

void addAfterCurr(list* l, char* url){
	if(l->curr==l->tail){
		append(url,strlen(url)+1,l);
	}
	else{
		forget(l);
		append(url,strlen(url)+1,l);
	}
}

char* readUrl(FILE* f, FILE* pad){
//	printf("Enter readUrl \n");
	char* url = malloc(3000);
	int i;
	char c = '-';
	for(i = 0; c != '\0' && !feof(f); ++i){
		c = fgetc(f);
	//	printf("C: %c \n",c);
		if(!feof(f) && !feof(pad)){
			c = decryptChar(pad, c);
		//	printf("after decrypt C: %c \n",c);
			url[i] = c;
		//	if(c=='\0'){
		//		printf("C is \\0\n");
		//	}
		}
		else{
			free(url);
			url = NULL;
		}
	}
//	printf("i: %d \n", i);
//	printf("in end of readUrl: %s \n", url);
	return url;
}

// pad is the pad file name not actual pad
int readFile(char* f, char* padFile, list* l){
//	printf("Enter readFile-> f: %s,padFile: %s\n", f, padFile); 
	FILE* pad = fopen(padFile, "rb");
	if(!pad){
		printf("Couldn't open file: %s \n", padFile);
		return 1;	
	}
	FILE* hFile = fopen(f, "rb");
	if(!hFile){
		printf("Couldn't open file: %s \n", f);
		return 1;
	}
	int pos;
	int read = fread(&pos, sizeof pos, 1, hFile);
	if(read!=1){
		printf("Error %d ints read \n", read);
		return 2;
	}
//	printf("pos: %d \n", pos);
	pos  = decryptNum(pad, pos);
//	printf("pos: %d \n", pos);
	char* url = readUrl(hFile, pad);
	//reading urls from file and adding them to the list
	while(url!=NULL){	
	//	printf("Entering loop \n");	
	//	printf("url: %s \n", url);
		append(url, strlen(url)+1, l);
		free(url);
		url = readUrl(hFile, pad);
	}
	int i;
	//moves current pointer of list to correct position from the file
	for(i=l->pos; i>pos; --i){
		back(l);
	}
	fclose(pad);
	fclose(hFile);
	return 0;//success
}

//decrypting position of current pointer
int decryptNum(FILE* pad, int num){	
	int i;
	int val=0;
	int temp;
	for(i=0; i<sizeof num; ++i){
		int part = (size_t) fgetc(pad);
		temp = part<<i*8;
		val += temp;
	}
        num = num ^ val;
	return num;
}

//decrypting character in a URL
char decryptChar(FILE* pad, char c){
        char padVal = getc(pad);
//	printf("Enter decryptChar with c: %c with padVal: %c\n",c,padVal);
	c = padVal^c;
//	printf("Exit decryptChar with c: %c\n", c);
	//DEBUG
//	if(c=='\0'){
//		printf("decrypted \\0\n");
//	}
	return c;
}

// pad is the pad file name not actual pad
int writeFile(char* f, char* padFile, list* l){
	FILE* pad = fopen(padFile, "wb");
	if(!pad){
		printf("Couldn't open file: %s \n", padFile);
		return 1;	
	}
	FILE* hFile = fopen(f, "wb");
	if(!hFile){
		printf("Couldn't open file: %s \n", f);
		return 1;	
	}
	int count = countUrlChar(l);
	char* strPad = createPad(count+sizeof l->pos+1);
//	printf("pad: %s \n", strPad);
	writePad(pad, strPad);
	fclose(pad);
	pad = fopen(padFile, "rb");
	int pos = encryptNum(pad, l->pos);
	int written = fwrite(&pos, sizeof pos, 1, hFile);
	if(written!=1){
		printf("Error: only %d ints written\n", written);
		return 2;
	}
	int i;
	node* it = l->head;
	for(i=0; i < l->size; ++i){
		char* url = malloc(strlen((char*) it->data)+2);
		strcpy(url, (char*) it->data);
	//	printf("Before enc: %s url len: %zu\n", url, strlen(url));
		url = encryptURL(pad, url);
	//	printf("After enc: %s url len: %zu\n", url, strlen(url));
		written = fwrite(url, strlen(url), 1, hFile);
		it = it->next;
		free(url);
	}
	fclose(pad);
	fclose(hFile);
	free(strPad);
	return 0;//success
}

char* createPad(int size){
	char* str = malloc(size);
        FILE* random = fopen("/dev/urandom", "rb");
	unsigned int seed;
	size_t read = fread(&seed, sizeof seed, 1, random);
	if(read!=1){
		printf("Error: only %zu bytes read\n", read);
	}
	srand(2);
	int i;
	for(i=0;i<size-1;++i){
		size_t range = 96;
		int val = rand()%range+32;
		str[i] = val;
	}
	str[size-1] = '\0';
	fclose(random);
	return str;
	
}

void writePad(FILE* padFile, char* pad){
	size_t written = fwrite(pad,strlen(pad), 1, padFile);
	if(written!=1){
		printf("Error: only %zu bytes written\n", written);
	}	
}

int countUrlChar(list* l){
	size_t tot = 0;
	node* it;
	for(it=l->head; it!=NULL; it=it->next){
		tot+=strlen((char*)it->data)+1;
	}
	return tot;
}

//pad is opened for reading
//url will be chnaged to encrypted url
//loops though file to encrypt each character in the url
char* encryptURL(FILE* pad, char* url){
	int i;
	int len = strlen(url);
	for(i=0;i<len+1;++i){
		char c = fgetc(pad);
	//	if(url[i]=='\0'){
	//		printf("url[i] is \\0\n");
	//	}
		url[i] = c ^ url[i];
	}
	url[len+1] = '\0';
//	printf("Exit encryptUrl: %s\n", url);
	return url;
}

// encrypts position or curr
int encryptNum(FILE* pad, int num){
	int i;
	int val=0;
	int temp;
	for(i=0; i<sizeof num; ++i){
		int part = (size_t) fgetc(pad);
		temp = part<<i*8;
		val += temp;
	}
        num = num ^ val;
	return num;
}
