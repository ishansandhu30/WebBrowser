#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

typedef struct node{
	void* data;
	struct node* prev;
	struct node* next;	
}node;

//doubly linked list
typedef struct list{
	node* head;
	node* tail;
	node* curr;
	int pos;//position of current
	int size;
	int maxSize;	
}list;

//time: O(1)
node* createNode(void* data, int size);

//create an empty list with no nodes
//time: O(1)
list* createList(int maxSize);

void delNode(node* n);

void delList(list* l);

void append(void* data, int size, list* l);

//removes node at the head of the list
void removeNode(list* l);


//moves back one towards the head of the list
void back(list* l);

//moves forward one towards the tail of the list
void forward(list* l);

//forgets subsequent URLs after current
void forget(list* l);

//prints their history from current in reverse order to start(head)
void printCurrReverse(list* l);

//prints their history from current in order to end(tail)
void printCurrForward(list* l);

//prints entire list labeling the current URL with an *
void printEntireList(list* l);


#endif //LINKEDLIST_H
 
