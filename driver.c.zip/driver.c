#include "driver.h"

void printHistory(int maxSize, char* padFile, char* hFile){
	list* l = createList(maxSize);
	readFile(hFile, padFile, l);
	printEntireList(l);
	delList(l);
}

void interact(int maxSize, char* padFile, char* hFile){
	list* l = createList(maxSize);
	char c = '-';
	while(c!='q'){
		switchAct(&c, padFile, hFile, l);
	}
	delList(l);
}

char menu(){
	int maxSize = 3000;
	char c ='-';
	printf("History Driver: \n");
	printf("----------------------\n");
	printf("v: visit a new url \n");
	printf("p: print the list \n");
	printf("b: back \n");
	printf("f: forward \n");
	printf("q: quit \n");
	char* temp = malloc(maxSize);
	fgets(temp, maxSize, stdin);
	c = temp[0];
	free(temp);
	return c;
}

void switchAct(char* c, char* padFile, char* hFile, list* l){
	*c = menu();
	int maxUrlSize = 3000;
	char* url;
	switch(c[0]){
		case 'v':
			url = malloc(maxUrlSize);
			printf("What url do you want to visit? \n");
			fgets(url,maxUrlSize,stdin);
			url[strlen(url)-1] = '\0';
			addAfterCurr(l,url);
			free(url);
			break;
		case 'p':
			printf("printing the list \n");
			printEntireList(l);
			printf("prints list from curr to front(tail)\n");
			printCurrForward(l);
			printf("printds list from curr to back(head)\n");
			printCurrReverse(l);
			break;
		
		case 'b':
			printf("going back in the list \n");
			back(l);
			printEntireList(l);
			break;
		
		case 'f':
			printf("going forward in the list \n");
			forward(l);
			printEntireList(l);
			break;
		case 'q':

			break;
		default:
			printf("Not a valid CHARACTER \n");
			break;
	}	
}

